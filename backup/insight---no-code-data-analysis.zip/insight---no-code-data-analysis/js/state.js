export const STATE = {
    data: [],
    columns: [],
    summary: {},
    types: {}
};
