import { STATE } from './state.js';

/* ---------- COLUMN TYPE DETECTION ---------- */
function detectColumnTypes(data, columns) {
    const types = {};

    columns.forEach(col => {
        let num = 0, date = 0, total = 0;

        data.forEach(row => {
            const v = row[col];
            if (v === null || v === undefined || v === '') return;
            total++;
            // Check for number (handling commas)
            const cleanV = String(v).replace(/,/g, '');
            if (!isNaN(cleanV) && cleanV.trim() !== '') num++;
            else if (!isNaN(Date.parse(v))) date++;
        });

        if (num / total > 0.8) types[col] = 'Number';
        else if (date / total > 0.8) types[col] = 'Date';
        else types[col] = 'Category';
    });

    return types;
}

/* ============================================================
   STATS UTILITIES (PURE FUNCTIONS)
   - No DOM
   - No Plotly
   - No UI state
   - Safe to reuse everywhere
============================================================ */

/* ---- basic helpers ---- */
function cleanNumeric(arr) {
    return arr
        .map(v => {
            if (v === null || v === undefined || v === '') return NaN;
            return Number(String(v).replace(/,/g, ''));
        })
        .filter(v => !isNaN(v));
}

/* ---- central tendency ---- */
function mean(arr) {
    const x = cleanNumeric(arr);
    return x.reduce((a, b) => a + b, 0) / x.length;
}

function median(arr) {
    const x = cleanNumeric(arr).sort((a, b) => a - b);
    const n = x.length;
    const mid = Math.floor(n / 2);
    return n % 2 !== 0
        ? x[mid]
        : (x[mid - 1] + x[mid]) / 2;
}

/* ---- spread ---- */
function min(arr) {
    return Math.min(...cleanNumeric(arr));
}

function max(arr) {
    return Math.max(...cleanNumeric(arr));
}

function variance(arr) {
    const x = cleanNumeric(arr);
    const m = mean(x);
    return x.reduce((s, v) => s + (v - m) ** 2, 0) / x.length;
}

function std(arr) {
    return Math.sqrt(variance(arr));
}

/* ---- quantiles ---- */
function quantile(arr, q) {
    const x = cleanNumeric(arr).sort((a, b) => a - b);
    const pos = (x.length - 1) * q;
    const base = Math.floor(pos);
    const rest = pos - base;
    return x[base + 1] !== undefined
        ? x[base] + rest * (x[base + 1] - x[base])
        : x[base];
}

/* ---- relationships ---- */
function pearsonCorr(x, y) {
    const a = cleanNumeric(x);
    const b = cleanNumeric(y);
    const n = Math.min(a.length, b.length);

    const mx = mean(a);
    const my = mean(b);

    let num = 0, dx = 0, dy = 0;
    for (let i = 0; i < n; i++) {
        num += (a[i] - mx) * (b[i] - my);
        dx += (a[i] - mx) ** 2;
        dy += (b[i] - my) ** 2;
    }
    return num / Math.sqrt(dx * dy);
}



/* ---------- MAIN RENDER ---------- */
export function renderDashboard() {
    const el = document.getElementById('content');

    STATE.types = detectColumnTypes(STATE.data, STATE.columns);

    const numericCols = STATE.columns.filter(c => STATE.types[c] === 'Number');
    const categoryCols = STATE.columns.filter(c => STATE.types[c] === 'Category');
    const dateCols = STATE.columns.filter(c => STATE.types[c] === 'Date');

    /* ---------- COLUMNS ---------- */
    const columnsHTML = `
    <div class="card">
      <h3>Columns</h3>
      <div class="column-list">
        ${STATE.columns.map(c => `
          <div class="column-item">
            <span>${c}</span>
            <span class="badge ${STATE.types[c].toLowerCase()}">${STATE.types[c]}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;

    /* ---------- FILTER + CONTROLS ---------- */
    const controlsHTML = `
    <div class="card">
      <h3>Chart Controls</h3>

      <label class="control-label">Chart Type</label>
      <select id="chart-type">
        <option value="histogram">Histogram</option>
        <option value="bar">Bar</option>
        <option value="line">Line</option>
        <option value="scatter">Scatter</option>
        <option value="correlation">Correlation Heatmap</option>
      </select>


      <label class="control-label">Numeric Column</label>
      <select id="num-col">
        ${numericCols.map(c => `<option value="${c}">${c}</option>`).join('')}
      </select>

      <div id="bin-control">
        <label class="control-label">
          Bin Count: <span id="bin-value">10</span>
        </label>
        <input type="range" id="bin-slider" min="5" max="50" value="10">
      </div>

      <label class="control-label">Category / Date Column</label>
      <select id="cat-col">
        ${[...categoryCols, ...dateCols]
            .map(c => `<option value="${c}">${c}</option>`).join('')}
      </select>

      <hr class="divider">

      <label class="control-label">Filter Category</label>
      <select id="filter-col">
        <option value="">None</option>
        ${categoryCols.map(c => `<option value="${c}">${c}</option>`).join('')}
      </select>

      <select id="filter-val" disabled></select>

      <p id="chart-hint" class="chart-hint"></p>
    </div>
  `;

    /* ---------- CHART ---------- */
    const chartHTML = `
    <div class="card">
      <h3 id="chart-title"></h3>
      <div id="chart" style="height:320px;"></div>
    </div>
  `;

    /* ---------- TABLE ---------- */
    const headers = STATE.columns.map(c => `<th>${c}</th>`).join('');

    function getFilteredData() {
        const fcol = document.getElementById('filter-col').value;
        const fval = document.getElementById('filter-val').value;

        if (!fcol || !fval) return STATE.data;
        return STATE.data.filter(r => r[fcol] == fval);
    }

    const tableHTML = `
    <div class="card">
      <h3>Data Preview</h3>
      <div class="table-container">
        <table>
          <thead><tr>${headers}</tr></thead>
          <tbody id="table-body"></tbody>
        </table>
      </div>
    </div>
  `;

    el.innerHTML = `
    ${columnsHTML}
    <div class="dashboard-grid">
      ${controlsHTML}
      ${chartHTML}
    </div>
    ${tableHTML}
  `;

    /* ---------- POPULATE FILTER VALUES ---------- */
    const filterCol = document.getElementById('filter-col');
    const filterVal = document.getElementById('filter-val');

    filterCol.addEventListener('change', () => {
        const col = filterCol.value;
        filterVal.innerHTML = '';
        if (!col) {
            filterVal.disabled = true;
            renderAll();
            return;
        }

        const values = [...new Set(STATE.data.map(r => r[col]))];
        values.forEach(v => {
            const opt = document.createElement('option');
            opt.value = v;
            opt.innerText = v;
            filterVal.appendChild(opt);
        });
        filterVal.disabled = false;
        renderAll();
    });

    filterVal.addEventListener('change', renderAll);

    /* ============================================================
    SUMMARY STATS (FOR SELECTED NUMERIC COLUMN)
    ============================================================ */
    function renderSummaryStats(data) {
        const numCol = document.getElementById('num-col').value;
        if (!numCol) return;

        // Use cleanNumeric to ensure we catch all numbers (including "1,000")
        const rawValues = data.map(r => r[numCol]);
        const values = cleanNumeric(rawValues);

        if (values.length === 0) return;

        const statsHTML = `
            <div id="summary-stats" class="card">
                <h3>Summary Statistics — ${numCol}</h3>
                <div class="stats">
                    <div class="stat">
                        <h4>Min</h4>
                        <p>${min(values).toFixed(2)}</p>
                    </div>
                    <div class="stat">
                        <h4>Max</h4>
                        <p>${max(values).toFixed(2)}</p>
                    </div>
                    <div class="stat">
                        <h4>Mean</h4>
                        <p>${mean(values).toFixed(2)}</p>
                    </div>
                    <div class="stat">
                        <h4>Median</h4>
                        <p>${median(values).toFixed(2)}</p>
                    </div>
                </div>
            </div>
        `;

        // Remove old stats card if exists
        const old = document.getElementById('summary-stats');
        if (old) old.remove();

        // Insert INSIDE dashboard grid (before chart card)
        const grid = document.querySelector('.dashboard-grid');
        const chartCard = document.getElementById('chart').closest('.card');

        grid.insertBefore(
            document.createRange().createContextualFragment(statsHTML),
            chartCard
        );
    }



    /* ---------- RENDER ALL ---------- */
    function renderAll() {
        const data = getFilteredData();

        // Update table
        const tbody = document.getElementById('table-body');
        tbody.innerHTML = data.map(row =>
            `<tr>${STATE.columns.map(c => `<td>${row[c]}</td>`).join('')}</tr>`
        ).join('');

        renderSummaryStats(data);
        renderChart(data);
    }

    /* ---------- CHART RENDER ---------- */
    function renderChart(data) {
        const type = document.getElementById('chart-type').value;
        const numColSelect = document.getElementById('num-col');
        const numCol = numColSelect.value;
        const catCol = document.getElementById('cat-col');
        const filterCol = document.getElementById('filter-col');
        const filterVal = document.getElementById('filter-val');
        const binControl = document.getElementById('bin-control');
        const bins = Number(document.getElementById('bin-slider').value);
        const hint = document.getElementById('chart-hint');

        /* ---------- PEARSON CORRELATION ---------- */
        function corr(x, y) {
            const n = x.length;
            const mx = x.reduce((a, b) => a + b, 0) / n;
            const my = y.reduce((a, b) => a + b, 0) / n;
            let num = 0, dx = 0, dy = 0;
            for (let i = 0; i < n; i++) {
                num += (x[i] - mx) * (y[i] - my);
                dx += (x[i] - mx) ** 2;
                dy += (y[i] - my) ** 2;
            }
            return num / Math.sqrt(dx * dy);
        }

        /* ---------- EXPORT CHART IMAGE ---------- */
        let exportBtn = document.getElementById('export-btn');
        if (!exportBtn) {
            exportBtn = document.createElement('button');
            exportBtn.id = 'export-btn';
            exportBtn.innerText = 'Export Chart';
            exportBtn.className = 'btn primary';
            document
                .querySelector('.card h3#chart-title')
                ?.parentElement
                ?.prepend(exportBtn);
        }

        exportBtn.onclick = () => {
            Plotly.downloadImage('chart', {
                format: 'png',
                filename: 'chart-export'
            });
        };

        /* ============================================================
           RESET CONTROL STATES (DEFAULT FOR NON-CORRELATION CHARTS)
        ============================================================ */
        numColSelect.disabled = false;
        catCol.disabled = false;
        filterCol.disabled = false;
        // filterVal enable/disable is handled elsewhere based on filterCol
        binControl.style.display = 'none';
        hint.innerText = '';
        const existingStrong = document.getElementById('strong-corr-card');
        if (existingStrong) existingStrong.remove();

        let plot = [];
        let title = '';

        /* ============================================================
           CORRELATION HEATMAP
        ============================================================ */
        if (type === 'correlation') {
            // Disable irrelevant controls
            numColSelect.disabled = true;
            catCol.disabled = true;
            filterCol.disabled = true;
            filterVal.disabled = true;
            binControl.style.display = 'none';

            hint.innerText =
                'Correlation heatmap shows relationships between numeric columns only.';

            const z = [];
            numericCols.forEach(a => {
                const row = [];
                numericCols.forEach(b => {
                    row.push(
                        corr(
                            data.map(r => Number(r[a])),
                            data.map(r => Number(r[b]))
                        )
                    );
                });
                z.push(row);
            });

            title = 'Correlation Heatmap';

            Plotly.newPlot(
                'chart',
                [{
                    z,
                    x: numericCols,
                    y: numericCols,
                    type: 'heatmap',
                    colorscale: 'RdBu',
                    zmin: -1,
                    zmax: 1
                }],
                {
                    margin: { t: 40 },
                    paper_bgcolor: 'transparent',
                    plot_bgcolor: 'transparent'
                }
            );

            /* ---------- HEATMAP CELL CLICK → SCATTER ---------- */
            const chartDiv = document.getElementById('chart');
            chartDiv.removeAllListeners('plotly_click');

            chartDiv.on('plotly_click', function (event) {
                const xIndex = event.points[0].x;
                const yIndex = event.points[0].y;

                const xCol = numericCols[xIndex];
                const yCol = numericCols[yIndex];

                // Switch UI to scatter
                document.getElementById('chart-type').value = 'scatter';
                document.getElementById('num-col').value = yCol;
                document.getElementById('cat-col').value = xCol;

                // Re-enable controls
                document.getElementById('num-col').disabled = false;
                document.getElementById('cat-col').disabled = false;
                document.getElementById('filter-col').disabled = false;

                renderAll();
            });

            document.getElementById('chart-title').innerText = title;
            // Removed return to allow flow into strong correlations
        }

        /* ---------- STRONG CORRELATIONS LIST ---------- */
        if (type === 'correlation') {
            const strong = [];

            for (let i = 0; i < numericCols.length; i++) {
                for (let j = i + 1; j < numericCols.length; j++) {
                    const a = numericCols[i];
                    const b = numericCols[j];
                    const c = corr(
                        data.map(r => Number(r[a])),
                        data.map(r => Number(r[b]))
                    );
                    if (Math.abs(c) >= 0.7) {
                        strong.push({ a, b, c });
                    }
                }
            }

            let html = '<div id="strong-corr-card" class="card"><h3>Strong Correlations (|r| ≥ 0.7)</h3>';

            if (strong.length === 0) {
                html += '<p class="muted">No strong correlations found.</p>';
            } else {
                html += '<ul>';
                strong.forEach(s => {
                    html += `<li>${s.a} ↔ ${s.b} : ${s.c.toFixed(2)}</li>`;
                });
                html += '</ul>';
            }

            html += '</div>';

            document
                .getElementById('content')
                .insertAdjacentHTML('beforeend', html);

            // Ensure UI state is consistent after correlation render
            document.getElementById('chart-type').disabled = false;

            return; // ⛔ stop here, do NOT run other chart logic
        }

        /* ============================================================
           HISTOGRAM
        ============================================================ */
        if (type === 'histogram') {
            binControl.style.display = 'block';
            catCol.disabled = true;
            hint.innerText =
                'Histogram shows distribution of a single numeric column.';

            const values = data.map(r => r[numCol]);
            const m = mean(values);
            const med = median(values);

            title = `${numCol} Distribution`;

            plot = [
                {
                    x: values,
                    type: 'histogram',
                    nbinsx: bins,
                    name: 'Distribution'
                },
                {
                    x: [m, m],
                    y: [0, 1],
                    mode: 'lines',
                    line: { dash: 'solid', color: 'red' },
                    name: 'Mean',
                    yaxis: 'y2'
                },
                {
                    x: [med, med],
                    y: [0, 1],
                    mode: 'lines',
                    line: { dash: 'dash', color: 'green' },
                    name: 'Median',
                    yaxis: 'y2'
                }
            ];

            Plotly.newPlot('chart', plot, {
                title: '',
                showlegend: true,
                yaxis2: {
                    overlaying: 'y',
                    visible: false
                }
            });

            document.getElementById('chart-title').innerText = title;
            return;
        }


        /* ============================================================
           BAR CHART
        ============================================================ */
        if (type === 'bar') {
            title = `${numCol} by ${catCol.value}`;
            const map = {};
            data.forEach(r => {
                map[r[catCol.value]] =
                    (map[r[catCol.value]] || 0) + Number(r[numCol]);
            });
            plot = [{
                x: Object.keys(map),
                y: Object.values(map),
                type: 'bar'
            }];
        }

        /* ============================================================
           LINE CHART
        ============================================================ */
        if (type === 'line') {
            title = `${numCol} over ${catCol.value}`;
            plot = [{
                x: data.map(r => r[catCol.value]),
                y: data.map(r => r[numCol]),
                type: 'scatter',
                mode: 'lines'
            }];
        }

        /* ============================================================
           SCATTER PLOT
        ============================================================ */
        if (type === 'scatter') {
            title = `${numCol} vs ${catCol.value}`;
            plot = [{
                x: data.map(r => r[catCol.value]),
                y: data.map(r => r[numCol]),
                type: 'scatter',
                mode: 'markers'
            }];
        }

        document.getElementById('chart-title').innerText = title;
        Plotly.newPlot('chart', plot);
    }

    document.querySelectorAll(
        '#chart-type, #num-col, #cat-col, #bin-slider'
    ).forEach(el => el.addEventListener('input', renderAll));

    renderAll();

}
