import { processData } from './api.js';
import { STATE } from './state.js';
import { renderDashboard } from './ui.js';

const modal = document.getElementById('modal');
const btn = document.getElementById('btn-new-project');

btn.onclick = () => modal.classList.remove('hidden');

document.getElementById('load').onclick = async () => {
    const text = document.getElementById('paste').value;
    const res = await processData(text);

    STATE.data = res.preview;
    STATE.columns = res.columns;
    STATE.summary = res.summary;

    modal.classList.add('hidden');
    renderDashboard();
};
